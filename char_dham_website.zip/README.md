# Char Dham Yatra Website

This is a static website with Netlify CMS based admin panel for managing content.